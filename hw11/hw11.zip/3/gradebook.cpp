#include "gradebook.h"

/**
	Now we change the gradebook again so that one can increment the
	score of a task (like in the first program).
*/

void GradeBook::add_student(string student)
{
	. . .
}

void GradeBook::add_score(string student, string task, int score)
{
	. . .
}

int GradeBook::get_score(string student, string task)
{
	. . .
}
