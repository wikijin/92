#include "gradebook.h"

/**
	Implement the member functions of the GradeBook class that uses
	a map to keep student scores.
*/

void GradeBook::add_student(string student)
{
	. . .
}

void GradeBook::add_score(string student, int score)
{
	. . .
}

int GradeBook::get_score(string student)
{
	. . .
}
