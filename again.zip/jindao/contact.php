<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>WEIYU Restaurant</title>

<!-- Favicon -->
<link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">

<!-- Google fonts - witch you want to use - (rest you can just remove) -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,500,400italic,500italic,700,900' rel='stylesheet' type='text/css'>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

<!-- Bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!--  CSS STYLES  -->
<link rel="stylesheet" href="css/style.css" type="text/css" />
<link rel="stylesheet" href="css/reset.css" type="text/css" />
<link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/Simple-Line-Icons-Webfont/simple-line-icons.css"/>
<link rel="stylesheet" href="css/et-line-font/et-line-font.css">

<!-- Responsive Devices Styles -->
<link rel="stylesheet" media="screen" href="css/responsive-leyouts.css" type="text/css" />

<!-- Mega Menu -->
<link href="js/mainmenu/menu.css" rel="stylesheet">

<!-- forms -->
<link rel="stylesheet" href="js/form/css/sky-forms.css" type="text/css" media="all">

<!-- Animations -->
<link href="js/animations/css/animations.min.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div class="site-wrapper"> 
  <header class="header headr-style-2"> 
    <div class="container">
    <div class="row"> 
      <!-- Menu -->
      <div class="navbar yamm navbar-default">
        <div class="container">
          <div class="navbar-header">
            <button type="button" data-toggle="collapse" data-target="#navbar-collapse-1" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            <a href="index.html" class="navbar-brand logo"></a> </div>
         
          <div id="navbar-collapse-1" class="navbar-collapse collapse pull-right dark-color nopadding">
            <nav>
              <ul class="nav navbar-nav">
                <!-- Classic list -->
                <li class="yamm-fw"><a>WEIYU RESTAURANT</a></li>
                <li class="yamm-fw"><a href="index.html" class="dropdown-toggle">Home</a></li>
                <li class="yamm-fw"><a href="./contact.php" class="pure-menu-link">Contact</a></li>
                <li class="yamm-fw"><a href="products.html">Products</a></li>
                <li class="yamm-fw"><a href="news.html">News</a></li>
                <li class="yamm-fw"><a href="about.html">About</a></li>
              </ul>
            </nav>
            
          </div>
        </div>
      </div>
    </div>
</div>
  </header>
  <!-- end Header --> 
  
  <!-- end page header -->
 <?php
$myfile = fopen("contact.txt", "r") or die("Unable to open file!");

echo nl2br( file_get_contents('contact.txt') );

fclose($myfile);
?>
  

  <footer class="footer-bg m-top0">
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-12 m-bottom2">
          <div class="call-to-action clearfix"><span class="fa fa-envelope-o font30 left"></span>
            <div class="feature-icon-col font-white left-padd9 m-top1">
              <h2 class="font20 font-white m-bottom1">Email</h2>
              <p><a href="mailto:info@example.com">weiyujin93@gmail.com</a></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-12 m-bottom2">
          <div class="call-to-action clearfix"><span class="fa fa-phone font30 left"></span>
            <div class="feature-icon-col font-white left-padd9 m-top1">
              <h2 class="font20 font-white m-bottom1">Phone</h2>
              <p>626-233-3546</p>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-12 m-bottom2">
          <div class="call-to-action clearfix"><span class="fa fa-map-marker font30 left"></span>
            <div class="feature-icon-col font-white left-padd9 m-top1">
              <h2 class="font-white font20 m-bottom1">Location</h2>
              <p>San Jose State University, San Jose, CA, USA</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <div class="copyrights">
    <div class="container">
      <div class="row text-center">
        <div class="col-md-12">
          <ul class="social-icons style-three">
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            <li><a href="#"><i class="fa fa-flickr"></i></a></li>
            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
            <li><a href="#"><i class="fa fa-vimeo-square"></i></a></li>
            <li><a href="#"><i class="fa fa-rss"></i></a></li>
          </ul>
        </div>
        <div class="col-md-12 m-top4"> Copyright &copy; 2016 yourdomian. All Rights Reserved. </div>
      </div>
    </div>
  </div>
  <!-- end footer --> 
</div>
<!-- site wrapper end --> 

<a href="#" class="scrollup"></a> 
<!-- end scroll to top of the page--> 

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery.min.js"></script> 

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/jquery.js"></script> 
<script src="js/bootstrap.min.js"></script> 

<!-- Animations --> 
<script src="js/animations/animations.min.js" type="text/javascript"></script> 
<script src="js/animations/appear.min.js" type="text/javascript"></script> 

<!-- Scroll to Fixied Sticky --> 
<script src="js/mainmenu/sticky.js" type="text/javascript"></script> 

<!-- Scroll Up --> 
<script src="js/scrolltotop/totop.js" type="text/javascript"></script> 

<!-- Counters --> 
<script src="js/aninum/jquery.animateNumber.min.js"></script>
</body>
</html>