//
// Created by TwoDog on 2017/4/25.
//

#include <iostream>
#include "Element.h"

using namespace std;

/***** Complete this class. *****/

/**
 * Default constructor.
 */
Element::Element() : value(0) {}

/**
 * Constructor.
 * @param val the element's value.
 */
Element::Element(long val) : value(val) {}

/**
 * Copy constructor.
 * @param other the other element to be copied.
 */
Element::Element(const Element& other)
{
    /***** Complete this class. *****/
}

/**
 * Destructor.
 */
Element::~Element()
{
    /***** Complete this class. *****/
}

/**
 * Getter.
 * @return the value.
 */
long Element::get_value() const { return value; }

