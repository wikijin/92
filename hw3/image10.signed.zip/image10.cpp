#include <vector>
#include "png.h"

using namespace std;

int main(int argc, char *argv[])
{
  vector<vector<int>> image = readGrayscaleImage("blimp.png");
  
  int m,n;
 
  
   for (m=0;m< image.size(); m++)
   {
    for (n=0;n< image[m].size(); n++)
    {
      
      if ((((m)*image[m].size()+n+1)%7==0)&&((m+n)>0))
      {
        image[m][n]=0;
      }
    }
    
  writeGrayscaleImage("out.png", image);
}

}