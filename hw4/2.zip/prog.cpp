int split(char* words)
{
	int i=0,j=1;
	while (words[i]!='\0')
	{
		if (words[i]==' ')
		{
			words[i]='\0';
			j++;
			
		}
		i++;
		
	}
	return(j);
}
