/*
  The print method receives as input a string followed by an asterisk 
  and an integer. Print out the string as many time as indicated 
  by the integer. For example, when called as print("Hi*3"), 
  you print HiHiHi. If no integer is specified, print the string
  once.

  Hint: Look for the '*' starting from the back of the string. 
  Then call atoi, passing a pointer to the integer starting after
  the '*'. You can also replace the '*' with a '\0' for easy
  printing of the first part.
*/

#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

void print(char* arg)
{    
	 int k=0,n=0 ;
	 for (int i=strlen(arg); i>0 ;i--)
	{
		k++;
		if (arg[i]=='*')
		{
			
			arg[i] = '\0';
			n= atoi(arg+i+1);
			break;
		}
				
	} 

	
	if(n==0)
	{
		cout << arg;
	}
	else{
	
	for (int b=0; b<n; b++)
	{
		cout << arg; 
	}
	}
	
	
	cout<<endl;
	
}
