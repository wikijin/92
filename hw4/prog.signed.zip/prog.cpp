void minmax(int* arr, int n, int* min, int* max)
{
	*min=999;
	for (int i=0;i<n;i++)
	{
		
		if (arr[i]<*min)
		{
			*min=arr[i];
		}
	}
	for (int i=0;i<n;i++)
	{	
		if (arr[i]>*max)
	{
		*max=arr[i];
	}
	}
	
}
